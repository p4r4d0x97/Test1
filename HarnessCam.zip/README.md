# Harness Camera Station

When the operator scans a barcode, the app takes one photo from each camera (1–3 or more), puts them side by side in a fixed left-to-right order, and saves the result as `<barcode>.jpg`.

## Install (Windows, once per PC)
1. Install Python 3.11 or newer from python.org. Tick **"Add Python to PATH"** during setup.
2. Copy this folder to the PC, for example `C:\HarnessCam`.
3. Double-click `start.bat`. The first run installs the packages it needs.
4. Right-click `install_reset_helper.bat` → **Run as administrator** (once). This enables camera reset without rebooting.

## First setup
1. Plug in all the cameras and open **⚙ Settings → Cameras**.
2. Click **Detect USB cameras**, then **Identify**. You get a snapshot from each camera, so you can tell which physical camera is which (wave a hand under one of them).
3. Use **+ Add slot** to add one slot per camera. Pick the camera for slot 1 (Left), then slot 2 (Middle), then slot 3 (Right).
4. Set **Rotate** if a camera is mounted the other way round.
5. Use **Crop L/R px** to cut off the area where two cameras overlap, so the joined image has no doubled section.
6. On the **General** tab, set the save folder. A network share such as `\\server\photos` works too.
7. Click **Save & apply**. Everything is stored in `config.json`, so you can copy that file to the other tables.

## How the camera order stays fixed
Windows changes the camera numbers (0, 1, 2) on reboot or replug, so the app does not use them. Each slot is tied to the camera's **device path**, which contains:
- the camera's **serial number**, if it has one (the best case: the camera can go in any USB port), or
- the **USB port** it is plugged into, if it has no serial number (most cheap webcams). In that case, **always plug each camera into the same port**. Label the cables and ports.

If a camera is missing at startup, its slot shows red and **scanning is blocked**. The app never saves a picture with cameras missing or out of order. When the camera is plugged back in, the app reconnects on its own within a few seconds.

Tip: buy cameras that report a USB serial number (many Logitech and industrial UVC cameras do). Two identical cameras without serial numbers can only be told apart by their USB port.

## LAN / IP cameras later
In the slot, set the type to `ip` and enter the stream URL, for example:
`rtsp://admin:password@192.168.1.50:554/stream1` (the exact path depends on the camera brand).
Give the camera a fixed IP address, and its order will never change. You can mix USB and IP cameras.

## Using it
- The barcode scanner must act as a keyboard and send Enter after the code. That is the default for most scanners.
- Green = saved. Red = not saved, with the reason shown.
- If the barcode already exists, the app saves `BARCODE_2.jpg` by default. You can change this to overwrite or block.
- Every scan is written to `scan_log.csv` in the save folder.
- Test mode: set a slot's type to `test` to try the app with no cameras attached.

## Camera reset (no PC reboot)
If a camera freezes or isn't detected, its badge turns red and shows **"click to reset"**.
- **Click the red badge** to reset that camera, or click **↻ Restart cameras** to reset all of them.
- The reset has two steps:
  1. **Reconnect**: the app closes and reopens the camera (about 1 second, no admin rights needed).
  2. **USB restart**: if the camera still doesn't work, Windows restarts that USB device. This is the same as unplugging and replugging it, and the other cameras and the barcode scanner are not affected.
- **Auto-reset**: a camera that has been down for 30 seconds is reset automatically, at most once every 3 minutes. You can change or turn this off in Settings → General.
- Step 2 needs admin rights. **Run `install_reset_helper.bat` once as administrator** on each PC. After that, operators can reset cameras without a password. Without the helper, the app asks Windows for admin (UAC) on a manual reset.
- Every USB restart is logged in `reset_log.txt`.
- If the reset doesn't fix it, the problem is physical: the cable, the USB port, or not enough USB power.

## Fast startup
The window opens straight away, and all cameras switch on at the same time in the background. The cameras stay open the whole time, so a scan saves almost instantly.
Do not build the app into a single-file .exe. Those unpack themselves at every start, which makes startup slower.

## Several USB cameras on one PC
Three HD cameras can overload one USB controller. Keep **Use MJPG** turned on. If a camera still fails to open, plug the cameras into different USB controllers (front and back ports, or a PCIe USB card), or lower the resolution.

## Start automatically with Windows
Press Win+R, type `shell:startup`, and put a shortcut to `start.bat` in that folder.
