"""
Harness Camera Station
----------------------
1-3 (or more) cameras above a harness work table. Operator scans the
barcode -> one photo from every camera is taken, placed side by side in a
fixed order, and saved as <barcode>.jpg in the configured folder.

Camera order is NOT based on USB index numbers (those change on reboot).
Each slot (Left / Middle / Right ...) is bound to the camera's hardware ID:
  * Windows: DirectShow device path (contains serial number or USB port)
  * Linux:   /dev/v4l/by-path/... (USB port) link
  * LAN:     the camera's RTSP/HTTP URL (always stable)

Requirements:  pip install opencv-python pillow cv2-enumerate-cameras
"""

import csv
import datetime as dt
import glob
import json
import os
import platform
import re
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import cv2
import numpy as np
from PIL import Image, ImageTk

APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"

SLOT_NAMES = ["Left", "Middle", "Right", "Slot 4", "Slot 5", "Slot 6"]

DEFAULT_CONFIG = {
    "station_name": "Table 1",
    "save_folder": os.path.join(os.path.expanduser("~"), "HarnessPhotos"),
    "date_subfolders": False,        # save into YYYY-MM-DD subfolders
    "save_single_images": False,     # also save <barcode>_cam1.jpg, ...
    "on_duplicate": "suffix",        # "suffix" -> BARCODE_2.jpg, "overwrite", "block"
    "jpeg_quality": 92,
    "barcode_min_length": 3,
    "barcode_regex": "",             # optional, e.g. "^[A-Z0-9-]+$"
    "settings_pin": "",              # optional PIN to protect settings
    "width": 1920,
    "height": 1080,
    "use_mjpg": True,                # needed for several HD USB cams on one PC
    "max_frame_age_s": 2.0,          # refuse to save if a camera frame is older
    "cameras": [
        # {"type": "usb", "id": "<device path>", "label": "...", "rotate": 0, "crop_left": 0, "crop_right": 0}
        # {"type": "ip",  "id": "rtsp://user:pass@192.168.1.50:554/stream1", ...}
        # {"type": "test","id": "test-1", ...}   (simulated camera, no hardware)
    ],
}


# --------------------------------------------------------------------------- config
def load_config():
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg.update(json.load(f))
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("Config", f"Could not read config.json:\n{e}\nUsing defaults.")
    return cfg


def save_config(cfg):
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CONFIG_PATH)


# --------------------------------------------------------------------------- camera discovery
def list_usb_cameras():
    """Return list of {id, name, index, backend}. 'id' is stable across reboots."""
    found = []
    if IS_WINDOWS:
        try:
            from cv2_enumerate_cameras import enumerate_cameras
            for c in enumerate_cameras(cv2.CAP_DSHOW):
                found.append({"id": c.path or f"{c.name}#{c.index}", "name": c.name,
                              "index": c.index, "backend": cv2.CAP_DSHOW})
        except Exception as e:  # noqa: BLE001
            print("Camera enumeration failed, falling back to indexes:", e)
    elif IS_LINUX:
        # by-path links are tied to the physical USB port
        for link in sorted(glob.glob("/dev/v4l/by-path/*-video-index0")):
            real = os.path.realpath(link)
            name = os.path.basename(link)
            try:
                dev = os.path.basename(real)
                with open(f"/sys/class/video4linux/{dev}/name") as f:
                    name = f.read().strip()
            except OSError:
                pass
            found.append({"id": link, "name": name, "index": real, "backend": cv2.CAP_V4L2})
    if not found:
        # generic fallback: probe indexes (order NOT guaranteed stable)
        for i in range(6):
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                found.append({"id": f"index:{i}", "name": f"Camera index {i}", "index": i,
                              "backend": cv2.CAP_ANY})
            cap.release()
    return found


def short_id(cam_id, n=28):
    return cam_id if len(cam_id) <= n else "…" + cam_id[-n:]


# --------------------------------------------------------------------------- camera worker
class CameraWorker(threading.Thread):
    """Keeps a camera open and always holds the newest frame (fast, fresh capture)."""

    def __init__(self, slot, cam_cfg, app_cfg):
        super().__init__(daemon=True)
        self.slot = slot
        self.cfg = cam_cfg
        self.app_cfg = app_cfg
        self.lock = threading.Lock()
        self.frame = None
        self.frame_time = 0.0
        self.status = "starting"
        self._halt = threading.Event()
        self.cap = None

    # -- opening
    def _open(self):
        t, cid = self.cfg.get("type", "usb"), self.cfg.get("id", "")
        if t == "test":
            return "test"
        if t == "ip":
            cap = cv2.VideoCapture(cid, cv2.CAP_FFMPEG)
        else:
            match = next((c for c in list_usb_cameras() if c["id"] == cid), None)
            if match is None:
                self.status = "NOT CONNECTED"
                return None
            cap = cv2.VideoCapture(match["index"], match["backend"])
            if self.app_cfg.get("use_mjpg", True):
                cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(self.app_cfg.get("width", 1920)))
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(self.app_cfg.get("height", 1080)))
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        if not cap.isOpened():
            cap.release()
            self.status = "OPEN FAILED"
            return None
        return cap

    def _test_frame(self):
        w, h = 1280, 720
        img = np.full((h, w, 3), (40 + 60 * self.slot, 90, 140), np.uint8)
        cv2.putText(img, f"TEST CAMERA {self.slot + 1}", (60, 200), cv2.FONT_HERSHEY_SIMPLEX, 3, (255, 255, 255), 6)
        cv2.putText(img, dt.datetime.now().strftime("%H:%M:%S.%f")[:-3], (60, 400),
                    cv2.FONT_HERSHEY_SIMPLEX, 2.5, (255, 255, 255), 5)
        time.sleep(0.05)
        return True, img

    def run(self):
        while not self._halt.is_set():
            if self.cap is None:
                self.cap = self._open()
                if self.cap is None:
                    self._halt.wait(3)          # retry every 3 s (camera unplugged etc.)
                    continue
            ok, img = self._test_frame() if self.cap == "test" else self.cap.read()
            if not ok or img is None:
                self.status = "NO SIGNAL"
                if self.cap != "test":
                    self.cap.release()
                self.cap = None
                self._halt.wait(2)
                continue
            with self.lock:
                self.frame, self.frame_time = img, time.time()
            self.status = "OK"
        if self.cap not in (None, "test"):
            self.cap.release()

    def latest(self):
        with self.lock:
            return (None if self.frame is None else self.frame.copy()), self.frame_time

    def stop(self):
        self._halt.set()


# --------------------------------------------------------------------------- image ops
def prepare(img, cam_cfg):
    rot = int(cam_cfg.get("rotate", 0)) % 360
    if rot == 90:
        img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    elif rot == 180:
        img = cv2.rotate(img, cv2.ROTATE_180)
    elif rot == 270:
        img = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
    w = img.shape[1]
    cl = max(0, int(cam_cfg.get("crop_left", 0)))
    cr = max(0, int(cam_cfg.get("crop_right", 0)))
    if cl + cr < w - 10:
        img = img[:, cl:w - cr]
    return img


def combine(images):
    """Put images side by side, scaled to a common height."""
    h = min(i.shape[0] for i in images)
    scaled = [i if i.shape[0] == h else cv2.resize(i, (int(i.shape[1] * h / i.shape[0]), h),
                                                    interpolation=cv2.INTER_AREA) for i in images]
    return cv2.hconcat(scaled)


def write_jpg(path, img, quality):
    # imencode + tofile works with non-ASCII paths on Windows (cv2.imwrite does not)
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, int(quality)])
    if not ok:
        raise IOError("JPEG encoding failed")
    tmp = path + ".part"
    buf.tofile(tmp)
    os.replace(tmp, path)


def safe_name(text):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", text).strip(" .")


# --------------------------------------------------------------------------- main app
class App:
    def __init__(self, root):
        self.root = root
        self.cfg = load_config()
        self.workers = []
        self.busy = False

        root.title("Harness Camera Station")
        root.geometry("1280x800")
        root.configure(bg="#1e1e1e")
        self._build_ui()
        self.start_workers()
        self.root.after(200, self.refresh_preview)
        self.root.after(500, lambda: self.entry.focus_force())
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        if not self.cfg["cameras"]:
            self.root.after(800, self.open_settings)

    # ---------------- UI
    def _build_ui(self):
        top = tk.Frame(self.root, bg="#1e1e1e")
        top.pack(fill="x", padx=10, pady=(10, 0))
        self.title_lbl = tk.Label(top, text=self.cfg["station_name"], fg="white", bg="#1e1e1e",
                                  font=("Segoe UI", 18, "bold"))
        self.title_lbl.pack(side="left")
        tk.Button(top, text="⚙ Settings", command=self.open_settings, font=("Segoe UI", 11)).pack(side="right")
        tk.Button(top, text="📁 Open folder", command=self.open_folder, font=("Segoe UI", 11)).pack(side="right", padx=6)
        self.cam_status = tk.Frame(top, bg="#1e1e1e")
        self.cam_status.pack(side="right", padx=20)

        self.preview = tk.Label(self.root, bg="black")
        self.preview.pack(fill="both", expand=True, padx=10, pady=10)

        bottom = tk.Frame(self.root, bg="#1e1e1e")
        bottom.pack(fill="x", padx=10, pady=(0, 10))
        tk.Label(bottom, text="Scan barcode:", fg="white", bg="#1e1e1e", font=("Segoe UI", 16)).pack(side="left")
        self.entry = tk.Entry(bottom, font=("Consolas", 22), width=30)
        self.entry.pack(side="left", padx=10)
        self.entry.bind("<Return>", self.on_scan)
        self.entry.bind("<KP_Enter>", self.on_scan)
        self.status = tk.Label(self.root, text="Ready", fg="white", bg="#444", font=("Segoe UI", 16, "bold"),
                               padx=12, pady=6, anchor="w")
        self.status.pack(fill="x", padx=10, pady=(0, 10))

        # keep focus in barcode field (operators click around)
        self.root.bind("<FocusIn>", lambda e: self.entry.focus_set() if e.widget == self.root else None)

    def set_status(self, text, color):
        self.status.config(text=text, bg=color)

    def render_cam_badges(self):
        for w in self.cam_status.winfo_children():
            w.destroy()
        self.badges = []
        for i, c in enumerate(self.cfg["cameras"]):
            b = tk.Label(self.cam_status, text=f"{SLOT_NAMES[i]}: …", font=("Segoe UI", 10, "bold"),
                         fg="white", bg="#666", padx=6, pady=2)
            b.pack(side="left", padx=3)
            self.badges.append(b)

    # ---------------- workers
    def start_workers(self):
        self.stop_workers()
        for i, c in enumerate(self.cfg["cameras"]):
            w = CameraWorker(i, c, self.cfg)
            w.start()
            self.workers.append(w)
        self.render_cam_badges()

    def stop_workers(self):
        for w in self.workers:
            w.stop()
        for w in self.workers:
            w.join(timeout=3)
        self.workers = []

    def refresh_preview(self):
        try:
            imgs, now = [], time.time()
            for i, w in enumerate(self.workers):
                frame, t = w.latest()
                fresh = frame is not None and now - t < self.cfg["max_frame_age_s"]
                if i < len(self.badges):
                    self.badges[i].config(text=f"{SLOT_NAMES[i]}: {'OK' if fresh else w.status}",
                                          bg="#2e7d32" if fresh else "#c62828")
                if frame is None:
                    frame = np.zeros((360, 640, 3), np.uint8)
                    cv2.putText(frame, f"{SLOT_NAMES[i]}: {w.status}", (20, 190),
                                cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)
                else:
                    frame = prepare(cv2.resize(frame, (640, int(frame.shape[0] * 640 / frame.shape[1]))),
                                    self._scaled_crop(w.cfg, frame.shape[1], 640))
                imgs.append(frame)
            if imgs:
                combo = combine(imgs)
                pw, ph = max(self.preview.winfo_width(), 100), max(self.preview.winfo_height(), 100)
                s = min(pw / combo.shape[1], ph / combo.shape[0])
                combo = cv2.resize(combo, (int(combo.shape[1] * s), int(combo.shape[0] * s)))
                photo = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(combo, cv2.COLOR_BGR2RGB)))
                self.preview.config(image=photo)
                self.preview.image = photo
        except Exception as e:  # noqa: BLE001
            print("preview error:", e)
        self.root.after(150, self.refresh_preview)

    @staticmethod
    def _scaled_crop(cam_cfg, full_w, small_w):
        c = dict(cam_cfg)
        f = small_w / max(full_w, 1)
        c["crop_left"] = int(c.get("crop_left", 0) * f)
        c["crop_right"] = int(c.get("crop_right", 0) * f)
        return c

    # ---------------- capture
    def on_scan(self, _event=None):
        code = self.entry.get().strip()
        self.entry.delete(0, "end")
        if self.busy or not code:
            return
        if len(code) < int(self.cfg.get("barcode_min_length", 0)):
            return self.fail(f"Barcode too short: {code}")
        rx = self.cfg.get("barcode_regex", "")
        if rx and not re.fullmatch(rx, code):
            return self.fail(f"Invalid barcode format: {code}")
        if not self.workers:
            return self.fail("No cameras configured – open Settings")

        frames, now = [], time.time()
        for i, w in enumerate(self.workers):
            f, t = w.latest()
            if f is None or now - t > self.cfg["max_frame_age_s"]:
                return self.fail(f"{SLOT_NAMES[i]} camera not ready ({w.status}) – photo NOT saved")
            frames.append(prepare(f, w.cfg))

        self.busy = True
        self.set_status(f"Saving {code} …", "#f9a825")
        threading.Thread(target=self._save, args=(code, frames), daemon=True).start()

    def _save(self, code, frames):
        try:
            folder = self.cfg["save_folder"]
            if self.cfg.get("date_subfolders"):
                folder = os.path.join(folder, dt.date.today().isoformat())
            os.makedirs(folder, exist_ok=True)
            base = safe_name(code)
            path = os.path.join(folder, base + ".jpg")
            mode = self.cfg.get("on_duplicate", "suffix")
            if os.path.exists(path):
                if mode == "block":
                    raise FileExistsError(f"{base}.jpg already exists – NOT saved")
                if mode == "suffix":
                    n = 2
                    while os.path.exists(os.path.join(folder, f"{base}_{n}.jpg")):
                        n += 1
                    base = f"{base}_{n}"
                    path = os.path.join(folder, base + ".jpg")
            q = self.cfg.get("jpeg_quality", 92)
            write_jpg(path, combine(frames) if len(frames) > 1 else frames[0], q)
            if self.cfg.get("save_single_images") and len(frames) > 1:
                for i, f in enumerate(frames):
                    write_jpg(os.path.join(folder, f"{base}_cam{i + 1}.jpg"), f, q)
            self._log(code, path, "OK")
            self.root.after(0, self.ok, f"✔ Saved {os.path.basename(path)}")
        except Exception as e:  # noqa: BLE001
            self._log(code, "", f"ERROR: {e}")
            self.root.after(0, self.fail, f"✖ {e}")
        finally:
            self.busy = False

    def _log(self, code, path, result):
        try:
            os.makedirs(self.cfg["save_folder"], exist_ok=True)
            log = os.path.join(self.cfg["save_folder"], "scan_log.csv")
            new = not os.path.exists(log)
            with open(log, "a", newline="", encoding="utf-8") as f:
                wr = csv.writer(f)
                if new:
                    wr.writerow(["timestamp", "station", "barcode", "file", "result"])
                wr.writerow([dt.datetime.now().isoformat(timespec="seconds"), self.cfg["station_name"],
                             code, path, result])
        except Exception as e:  # noqa: BLE001
            print("log error:", e)

    def ok(self, msg):
        self.set_status(msg, "#2e7d32")
        self.root.bell()
        self.entry.focus_set()

    def fail(self, msg):
        self.set_status(msg, "#c62828")
        for _ in range(3):
            self.root.bell()
        self.entry.focus_set()

    # ---------------- misc
    def open_folder(self):
        p = self.cfg["save_folder"]
        os.makedirs(p, exist_ok=True)
        if IS_WINDOWS:
            os.startfile(p)  # noqa: S606
        else:
            os.system(f'xdg-open "{p}" &')  # noqa: S605

    def open_settings(self):
        pin = self.cfg.get("settings_pin", "")
        if pin:
            from tkinter import simpledialog
            if simpledialog.askstring("Settings", "PIN:", show="*", parent=self.root) != pin:
                return
        SettingsWindow(self)

    def apply_config(self, cfg):
        self.cfg = cfg
        save_config(cfg)
        self.title_lbl.config(text=cfg["station_name"])
        self.start_workers()
        self.set_status("Settings saved – ready", "#444")
        self.entry.focus_set()

    def on_close(self):
        self.stop_workers()
        self.root.destroy()


# --------------------------------------------------------------------------- settings
class SettingsWindow:
    def __init__(self, app):
        self.app = app
        self.cfg = json.loads(json.dumps(app.cfg))
        self.win = tk.Toplevel(app.root)
        self.win.title("Settings")
        self.win.geometry("1000x680")
        self.win.transient(app.root)
        self.win.grab_set()
        self.detected = []
        self.rows = []

        nb = ttk.Notebook(self.win)
        nb.pack(fill="both", expand=True, padx=8, pady=8)
        self.cam_tab = ttk.Frame(nb)
        gen = ttk.Frame(nb)
        nb.add(self.cam_tab, text="Cameras")
        nb.add(gen, text="General")
        self._build_general(gen)
        self._build_cameras()

        bar = ttk.Frame(self.win)
        bar.pack(fill="x", padx=8, pady=8)
        ttk.Button(bar, text="Save & apply", command=self.save).pack(side="right")
        ttk.Button(bar, text="Cancel", command=self.win.destroy).pack(side="right", padx=6)

    # ---- general tab
    def _build_general(self, f):
        self.vars = {}

        def row(r, label, key, kind="entry", values=None):
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="w", padx=8, pady=5)
            val = self.cfg.get(key)
            if kind == "check":
                v = tk.BooleanVar(value=bool(val))
                ttk.Checkbutton(f, variable=v).grid(row=r, column=1, sticky="w")
            elif kind == "combo":
                v = tk.StringVar(value=str(val))
                ttk.Combobox(f, textvariable=v, values=values, state="readonly", width=20).grid(row=r, column=1, sticky="w")
            else:
                v = tk.StringVar(value=str(val))
                ttk.Entry(f, textvariable=v, width=60).grid(row=r, column=1, sticky="w")
            self.vars[key] = v

        row(0, "Station name", "station_name")
        row(1, "Save folder (local or \\\\server\\share)", "save_folder")
        ttk.Button(f, text="Browse…", command=self._browse).grid(row=1, column=2, padx=4)
        row(2, "Date subfolders (YYYY-MM-DD)", "date_subfolders", "check")
        row(3, "Also save each camera separately", "save_single_images", "check")
        row(4, "If barcode already exists", "on_duplicate", "combo", ["suffix", "overwrite", "block"])
        row(5, "JPEG quality (50-100)", "jpeg_quality")
        row(6, "Barcode minimum length", "barcode_min_length")
        row(7, "Barcode regex (optional)", "barcode_regex")
        row(8, "USB capture width", "width")
        row(9, "USB capture height", "height")
        row(10, "Use MJPG (recommended for multiple USB cams)", "use_mjpg", "check")
        row(11, "Settings PIN (empty = none)", "settings_pin")

    def _browse(self):
        d = filedialog.askdirectory(parent=self.win, initialdir=self.vars["save_folder"].get())
        if d:
            self.vars["save_folder"].set(os.path.normpath(d))

    # ---- cameras tab
    def _build_cameras(self):
        for w in self.cam_tab.winfo_children():
            w.destroy()
        top = ttk.Frame(self.cam_tab)
        top.pack(fill="x", padx=8, pady=6)
        ttk.Label(top, text="Slots are saved left → right. Each slot is locked to the camera's hardware ID, "
                            "so order survives restarts.", wraplength=900).pack(anchor="w")
        btns = ttk.Frame(self.cam_tab)
        btns.pack(fill="x", padx=8)
        ttk.Button(btns, text="🔍 Detect USB cameras", command=self.detect).pack(side="left")
        ttk.Button(btns, text="👁 Identify (show detected cameras)", command=self.identify).pack(side="left", padx=6)
        ttk.Button(btns, text="+ Add slot", command=self.add_slot).pack(side="left", padx=6)
        self.det_lbl = ttk.Label(btns, text="")
        self.det_lbl.pack(side="left", padx=10)

        self.slot_frame = ttk.Frame(self.cam_tab)
        self.slot_frame.pack(fill="both", expand=True, padx=8, pady=8)
        self.draw_slots()

    def detect(self):
        self.app.stop_workers()  # release cameras so they can be probed (restarted on save/cancel)
        self.win.bind("<Destroy>", lambda e: self.app.start_workers() if e.widget == self.win and not self.app.workers else None)
        self.detected = list_usb_cameras()
        self.det_lbl.config(text=f"{len(self.detected)} USB camera(s) found")
        self.draw_slots()

    def cam_label(self, c):
        return f"{c['name']}  [{short_id(c['id'])}]"

    def draw_slots(self):
        for w in self.slot_frame.winfo_children():
            w.destroy()
        self.rows = []
        hdr = ["Slot", "Type", "Camera / URL", "Rotate", "Crop L px", "Crop R px", ""]
        for j, h in enumerate(hdr):
            ttk.Label(self.slot_frame, text=h, font=("Segoe UI", 9, "bold")).grid(row=0, column=j, sticky="w", padx=4)
        options = [self.cam_label(c) for c in self.detected]
        for i, cam in enumerate(self.cfg["cameras"]):
            r = i + 1
            ttk.Label(self.slot_frame, text=f"{i + 1}. {SLOT_NAMES[i]}").grid(row=r, column=0, sticky="w", padx=4, pady=4)
            tv = tk.StringVar(value=cam.get("type", "usb"))
            ttk.Combobox(self.slot_frame, textvariable=tv, values=["usb", "ip", "test"], state="readonly",
                         width=6).grid(row=r, column=1, padx=4)
            # camera selector: show stored camera even if not currently detected
            stored = next((self.cam_label(c) for c in self.detected if c["id"] == cam.get("id")), None)
            if stored is None and cam.get("id"):
                stored = (cam.get("label") or "saved camera") + f"  [{short_id(cam['id'])}]"
            idv = tk.StringVar(value=cam.get("id", "") if cam.get("type") in ("ip", "test") else (stored or ""))
            cb = ttk.Combobox(self.slot_frame, textvariable=idv, values=options, width=60)
            cb.grid(row=r, column=2, padx=4, sticky="w")
            rot = tk.StringVar(value=str(cam.get("rotate", 0)))
            ttk.Combobox(self.slot_frame, textvariable=rot, values=["0", "90", "180", "270"], width=5,
                         state="readonly").grid(row=r, column=3, padx=4)
            cl = tk.StringVar(value=str(cam.get("crop_left", 0)))
            cr = tk.StringVar(value=str(cam.get("crop_right", 0)))
            ttk.Entry(self.slot_frame, textvariable=cl, width=7).grid(row=r, column=4, padx=4)
            ttk.Entry(self.slot_frame, textvariable=cr, width=7).grid(row=r, column=5, padx=4)
            act = ttk.Frame(self.slot_frame)
            act.grid(row=r, column=6)
            ttk.Button(act, text="▲", width=3, command=lambda i=i: self.move(i, -1)).pack(side="left")
            ttk.Button(act, text="▼", width=3, command=lambda i=i: self.move(i, 1)).pack(side="left")
            ttk.Button(act, text="✕", width=3, command=lambda i=i: self.remove(i)).pack(side="left")
            self.rows.append({"type": tv, "id": idv, "rotate": rot, "crop_left": cl, "crop_right": cr,
                              "orig": cam})
        ttk.Label(self.slot_frame, foreground="#555", wraplength=900, justify="left", text=(
            "usb: pick a camera from the list (press Detect first).   "
            "ip: type the stream URL, e.g. rtsp://admin:pass@192.168.1.50:554/stream1   "
            "test: simulated camera.\n"
            "Crop L/R removes overlapping pixels at the edges (in full-resolution pixels) so the side-by-side "
            "image has no duplicated area.")).grid(row=len(self.rows) + 1, column=0, columnspan=7, sticky="w", pady=12)

    def collect_slots(self):
        cams = []
        label_to_cam = {self.cam_label(c): c for c in self.detected}
        for row in self.rows:
            t = row["type"].get()
            val = row["id"].get().strip()
            entry = {"type": t, "rotate": int(row["rotate"].get() or 0),
                     "crop_left": int(row["crop_left"].get() or 0), "crop_right": int(row["crop_right"].get() or 0)}
            if t == "usb":
                if val in label_to_cam:
                    entry["id"], entry["label"] = label_to_cam[val]["id"], label_to_cam[val]["name"]
                else:  # unchanged, camera currently not detected
                    entry["id"], entry["label"] = row["orig"].get("id", ""), row["orig"].get("label", "")
            else:
                entry["id"] = val
            cams.append(entry)
        return cams

    def add_slot(self):
        self.cfg["cameras"] = self.collect_slots()
        self.cfg["cameras"].append({"type": "usb", "id": "", "rotate": 0, "crop_left": 0, "crop_right": 0})
        self.draw_slots()

    def move(self, i, d):
        cams = self.collect_slots()
        j = i + d
        if 0 <= j < len(cams):
            cams[i], cams[j] = cams[j], cams[i]
            self.cfg["cameras"] = cams
            self.draw_slots()

    def remove(self, i):
        cams = self.collect_slots()
        cams.pop(i)
        self.cfg["cameras"] = cams
        self.draw_slots()

    def identify(self):
        """Show one snapshot per detected USB camera so you can see which physical camera is which."""
        if not self.detected:
            self.detect()
        if not self.detected:
            messagebox.showinfo("Identify", "No USB cameras detected.", parent=self.win)
            return
        top = tk.Toplevel(self.win)
        top.title("Detected cameras – wave your hand under each one")
        photos = []
        for k, c in enumerate(self.detected):
            cap = cv2.VideoCapture(c["index"], c["backend"])
            img = None
            for _ in range(10):  # let auto-exposure settle
                ok, f = cap.read()
                if ok:
                    img = f
            cap.release()
            if img is None:
                img = np.zeros((240, 320, 3), np.uint8)
            img = cv2.resize(img, (400, int(img.shape[0] * 400 / img.shape[1])))
            ph = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)))
            photos.append(ph)
            fr = ttk.Frame(top)
            fr.grid(row=k // 3, column=k % 3, padx=6, pady=6)
            tk.Label(fr, image=ph).pack()
            ttk.Label(fr, text=self.cam_label(c), wraplength=400).pack()
        top.photos = photos

    def save(self):
        try:
            cfg = self.cfg
            cfg["cameras"] = self.collect_slots()
            for k, v in self.vars.items():
                val = v.get()
                if k in ("jpeg_quality", "barcode_min_length", "width", "height"):
                    val = int(val)
                cfg[k] = val
            ids = [c["id"] for c in cfg["cameras"]]
            if any(not i for i in ids):
                raise ValueError("Every slot needs a camera (or remove the empty slot).")
            if len(set(ids)) != len(ids):
                raise ValueError("The same camera is assigned to two slots.")
            if cfg["barcode_regex"]:
                re.compile(cfg["barcode_regex"])
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("Settings", str(e), parent=self.win)
            return
        self.win.unbind("<Destroy>")
        self.win.destroy()
        self.app.apply_config(cfg)


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista" if IS_WINDOWS else "clam")
    except tk.TclError:
        pass
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
