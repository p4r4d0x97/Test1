@echo off
REM Run ONCE as administrator. Creates a Windows scheduled task that lets the
REM camera app restart USB cameras without asking for an admin password.
cd /d "%~dp0"
net session >nul 2>&1 || (
  echo Requesting administrator rights...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_reset_helper.ps1"
pause
