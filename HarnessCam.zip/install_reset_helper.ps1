# Creates the "HarnessCam Camera Reset" task (runs reset_cameras.ps1 as SYSTEM)
# and allows normal users to start it.
$name   = 'HarnessCam Camera Reset'
$dir    = $PSScriptRoot
$script = Join-Path $dir 'reset_cameras.ps1'

$action    = New-ScheduledTaskAction -Execute 'powershell.exe' `
             -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$script`" -AppDir `"$dir`""
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
             -ExecutionTimeLimit (New-TimeSpan -Minutes 2) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $name -Action $action -Principal $principal -Settings $settings -Force | Out-Null

# allow Authenticated Users to read + run the task
$svc  = New-Object -ComObject 'Schedule.Service'
$svc.Connect()
$task = $svc.GetFolder('\').GetTask($name)
$sd   = $task.GetSecurityDescriptor(4)
if ($sd -notmatch '\(A;;GRGX;;;AU\)') { $task.SetSecurityDescriptor($sd + '(A;;GRGX;;;AU)', 0) }

Write-Host ''
Write-Host "OK - '$name' installed. Operators can now reset cameras from the app." -ForegroundColor Green
