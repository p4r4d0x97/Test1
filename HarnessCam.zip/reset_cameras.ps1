# Restarts USB camera devices (same effect as unplug / replug).
# Called by harness_cam.py - needs admin rights (via the scheduled task helper or UAC).
param([string]$AppDir = $PSScriptRoot)

$req  = Join-Path $AppDir 'reset_request.json'
$done = Join-Path $AppDir 'reset_done.json'
$log  = Join-Path $AppDir 'reset_log.txt'

$r = Get-Content $req -Raw | ConvertFrom-Json
$results = @()

foreach ($id in $r.ids) {
    $target = $id
    # A camera interface (...&MI_00) belongs to a composite USB device: restart the whole device.
    if ($id -match '&MI_[0-9A-F]{2}') {
        try {
            $p = (Get-PnpDeviceProperty -InstanceId $id -KeyName 'DEVPKEY_Device_Parent' -ErrorAction Stop).Data
            if ($p) { $target = $p }
        } catch {}
    }
    $out = (& pnputil /restart-device "$target" 2>&1 | Out-String)
    $ok = ($LASTEXITCODE -eq 0)
    if (-not $ok) {
        # older Windows / restart refused: disable + enable
        try {
            Disable-PnpDevice -InstanceId $target -Confirm:$false -ErrorAction Stop
            Start-Sleep -Milliseconds 1500
            Enable-PnpDevice -InstanceId $target -Confirm:$false -ErrorAction Stop
            $ok = $true
            $out += ' | disable/enable OK'
        } catch { $out += ' | ' + $_.Exception.Message }
    }
    $results += [pscustomobject]@{ id = $id; target = $target; ok = $ok; output = $out.Trim() }
}

# re-detect hardware (brings back devices that dropped off)
& pnputil /scan-devices | Out-Null

"$(Get-Date -Format s)  $(ConvertTo-Json -InputObject @($results) -Compress)" | Add-Content $log
ConvertTo-Json -InputObject @{ token = $r.token; results = @($results) } -Depth 4 | Set-Content $done -Encoding UTF8
