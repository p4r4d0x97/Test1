@echo off
cd /d "%~dp0"
python -c "import cv2, PIL, cv2_enumerate_cameras" 2>nul || (
  echo Installing required packages...
  python -m pip install -r requirements.txt
)
start "" pythonw harness_cam.py
